import torch
from transformers import BertTokenizer, BertModel
from torch import nn
from torch.utils.data import Dataset, DataLoader
import json
from tqdm import tqdm
import torch.nn.parallel
import numpy as np
from torch.optim import Adam
import argparse
from peft import LoraModel, get_peft_model, LoraConfig
import random
import torch.nn.functional as F

parser = argparse.ArgumentParser()
parser.add_argument("-rs", dest="random_seed", type=int, default=1337, help="Random Seed (Default: 1337)")

args = parser.parse_args()

# Initial Setup
np.random.seed(args.random_seed)
torch.manual_seed(args.random_seed)

def split_data(data, train_ratio, eval_ratio, test_ratio):
    np.random.shuffle(data)  # Shuffle the data randomly
    num_total = len(data)

    num_train = int(num_total * train_ratio)
    num_eval = int(num_total * eval_ratio)
    num_test = num_total - num_train - num_eval

    train_data = data[:num_train]
    eval_data = data[num_train:num_train + num_eval]
    test_data = data[num_train + num_eval:]

    return train_data, eval_data, test_data

def process_data():
    # Read the JSON file
    data = []
    with open('datasets/reviews_amazon_instant_video.json', 'r') as f:
    # with open('datasets/musical_instruments.json', 'r') as f:
        for line in f:
            json_data = json.loads(line)
            data.append(json_data)

    # Define an empty list to store processed data
    preform_data = []
    user_reviews = {}
    item_reviews = {}
    # Build a mapping dictionary from user ID to integer index
    user_id_to_index = {}
    for example in data:
        user_id = example['reviewerID']
        if user_id not in user_id_to_index:
            user_id_to_index[user_id] = len(user_id_to_index)

    # Build a mapping dictionary from item ID to integer index
    item_id_to_index = {}
    for example in data:
        item_id = example['asin']
        if item_id not in item_id_to_index:
            item_id_to_index[item_id] = len(item_id_to_index)

    tokenizer = BertTokenizer.from_pretrained('bert-base-cased')
    # Iterate through the JSON data
    for example in tqdm(data):
        user_id = example['reviewerID']
        item_id = example['asin']
        review = example['reviewText']
        label = example['overall']

        # Convert the user ID and item ID to tensors
        user_id_index = user_id_to_index[user_id]
        user_id_tensor = torch.LongTensor([user_id_index])
        item_id_index = item_id_to_index[item_id]
        item_id_tensor = torch.LongTensor([item_id_index])
        if user_id_index not in user_reviews:
            user_reviews[user_id_index] = []
        user_reviews[user_id_index].append(review)
        if item_id_index not in item_reviews:
            item_reviews[item_id_index] = []
        item_reviews[item_id_index].append(review)
        label_tensor = torch.tensor(label)
        # Build the sample dictionary and add it to the evaluation data list
        preform_data.append({
                             'label_tensor': label_tensor,
                             'user_id_tensor': user_id_tensor,
                             'item_id_tensor': item_id_tensor
                             })


    return preform_data, user_reviews, item_reviews
class LoRAModel(torch.nn.Module):
    def __init__(self, config, ckpt_list, dropout=0.5):
        super(LoRAModel, self).__init__()
        self.lora_models = torch.nn.ModuleList()
        for ckpt_path in ckpt_list:
            lora_model = self.get_lora_model(config, ckpt_path)
            self.lora_models.append(lora_model)
        self.dropout = nn.Dropout(dropout)
        self.linear = nn.Linear(1536, 768)
        self.relu = nn.ReLU()

    def get_lora_model(self, config, ckpt_path):
        lora_model = BertModel.from_pretrained('bert-base-cased')
        lora_model = get_peft_model(lora_model, config)
        lora_model.print_trainable_parameters()
        checkpoint = torch.load(ckpt_path)
        checkpoint['model_state_dict'] = {k.replace("base_model.model.bert", "base_model.model"): v for k, v in
                                          checkpoint['model_state_dict'].items()}
        lora_model.load_state_dict(checkpoint['model_state_dict'], strict=False)
        lora_model.merge_and_unload()
        return lora_model

    def forward(self, input_ids, attention_mask):
        cls_embeddings = []
        for lora_model in self.lora_models:
            outputs = lora_model(input_ids=input_ids, attention_mask=attention_mask)
            cls_embedding = outputs[0][:, 0, :]
            cls_embeddings.append(cls_embedding)
        pooled_output = torch.cat(cls_embeddings, dim=1)
        pooled_output = self.linear(pooled_output)
        return pooled_output.squeeze(-1)

class InfoNCELoss(nn.Module):
    def __init__(self, temperature=0.2):
        super(InfoNCELoss, self).__init__()
        self.temperature = temperature

    def forward(self, anchor, positive, negative):
        # Reshape positive and negative tensors
        anchor = anchor.view(batch_size,768)
        positive_flat = positive.view(batch_size, 768)
        negative_flat = negative.view(batch_size, 768)

        # Calculate similarity matrix
        pos_sim = torch.matmul(anchor, positive_flat.t()) / self.temperature
        neg_sim = torch.matmul(anchor, negative_flat.t()) / self.temperature

        # Construct label vector
        bsz = anchor.size(0)
        labels = torch.zeros(bsz, dtype=torch.long).to(anchor.device)

        # Calculate loss
        logits = torch.cat([pos_sim, neg_sim], dim=1)
        loss = nn.CrossEntropyLoss()(logits, labels)

        return loss

class TripletLoss(nn.Module):
    def __init__(self, margin=1.0):
        super(TripletLoss, self).__init__()
        self.margin = margin

    def forward(self, anchor, positive, negative):
        distance_positive = F.pairwise_distance(anchor, positive, p=2)
        distance_negative = F.pairwise_distance(anchor, negative, p=2)
        loss = F.relu(distance_positive - distance_negative + self.margin)
        return torch.mean(loss)

class BertRegressor(nn.Module):
    def __init__(self, user_reviews, item_reviews, dropout=0.5):
        super(BertRegressor, self).__init__()
        # Load pre-trained BERT model and tokenizer
        self.bert = BertModel.from_pretrained('bert-base-cased')
        self.tokenizer = BertTokenizer.from_pretrained('bert-base-cased')
        self.user_reviews = user_reviews
        self.item_reviews = item_reviews
        # Define layers and loss functions
        self.fc = nn.Linear(1536, 768)
        self.dropout = nn.Dropout(dropout)
        self.linear = nn.Linear(768, 1)
        self.contrastive_loss = InfoNCELoss(temperature=0.2)
        self.attention_linear = nn.Linear(1536, 1)
        self.multihead_attn = torch.nn.MultiheadAttention(768, 8, 0)
        self.triplet_loss = TripletLoss(margin=1.0)

    def forward(self, user_id, item_id):
        user_id_embedding = emb_for_uid(user_id)
        item_id_embedding = emb_for_iid(item_id)
        user_review_attn = []
        item_review_attn = []
        user_reviews_input = []
        item_review_input = []
        for i in range(batch_size):
            review_input = []
            for j in range(5):  # Limit the number of reviews to 5
                if j < len(self.user_reviews[user_id[i].item()]):
                    review = self.user_reviews[user_id[i].item()][j]
                else:
                    review = ""  # Fill with empty string if the number of reviews is less than 5
                input_tokens = self.tokenizer(review,
                                              padding='max_length',
                                              truncation=True,
                                              max_length=128,
                                              add_special_tokens=True)
                input_id_tensor = torch.tensor(input_tokens['input_ids']).unsqueeze(0)
                attention_mask_tensor = torch.tensor(input_tokens['attention_mask']).unsqueeze(0)
                input_id_tensor = input_id_tensor.to(device)
                attention_mask_tensor = attention_mask_tensor.to(device)
                review_input.append((input_id_tensor, attention_mask_tensor))

            input_ids = torch.cat([t[0] for t in review_input], dim=0).unsqueeze(0)
            attention_masks = torch.cat([t[1] for t in review_input], dim=0).unsqueeze(0)
            user_reviews_input.append((input_ids, attention_masks))

        input_ids = torch.cat([t[0] for t in user_reviews_input], dim=0)
        attention_masks = torch.cat([t[1] for t in user_reviews_input], dim=0)
        input_ids_flat = input_ids.view(-1, 128)
        attention_masks_flat = attention_masks.view(-1, 128)
        outputs = self.bert(input_ids=input_ids_flat, attention_mask=attention_masks_flat)
        pooler_output = outputs.pooler_output
        pooler_output = pooler_output.view(batch_size, 5,-1)
        # user_review_attn.append(pooler_output)
        for i in range(batch_size):
            query = item_id_embedding[i]
            key = pooler_output[i]
            value = pooler_output[i]
            weighted_output, attention_map = self.multihead_attn(query, key, value)
            # Append the attention-weighted output to the list
            user_review_attn.append(weighted_output)

        # Perform contrastive learning within the batch
        user_review_attn = torch.stack(user_review_attn, dim=0)  # shape: (batch_size, hidden_size)
        user_review_attn_pos_idx = torch.LongTensor([i for i in range(batch_size)]).to(device)
        user_pooled_output = user_review_attn[user_review_attn_pos_idx]
        user_review_attn_pos = user_id_embedding[user_review_attn_pos_idx].squeeze(1)
        user_review_attn_neg_idx = torch.LongTensor([random.choice([j for j in range(batch_size) if j != i]) for i in range(batch_size)]).to(device)
        user_review_attn_neg = user_id_embedding[user_review_attn_neg_idx].squeeze(1)
        user_review_attn_loss = self.triplet_loss(user_review_attn, user_review_attn_pos, user_review_attn_neg)

        # Process each review for the item
        for i in range(batch_size):
            review_input = []
            for j in range(5):  # Limit the number of reviews to 5
                if j < len(self.item_reviews[item_id[i].item()]):
                    review = self.item_reviews[item_id[i].item()][j]
                else:
                    review = ""

                input_tokens = self.tokenizer(review,
                                              padding='max_length',
                                              truncation=True,
                                              max_length=128,
                                              add_special_tokens=True)
                input_id_tensor = torch.tensor(input_tokens['input_ids']).unsqueeze(0)
                attention_mask_tensor = torch.tensor(input_tokens['attention_mask']).unsqueeze(0)
                input_id_tensor = input_id_tensor.to(device)
                attention_mask_tensor = attention_mask_tensor.to(device)
                review_input.append((input_id_tensor, attention_mask_tensor))

            input_ids = torch.cat([t[0] for t in review_input], dim=0).unsqueeze(0)
            attention_masks = torch.cat([t[1] for t in review_input], dim=0).unsqueeze(0)
            item_review_input.append((input_ids, attention_masks))

        input_ids = torch.cat([t[0] for t in item_review_input], dim=0)
        attention_masks = torch.cat([t[1] for t in item_review_input], dim=0)
        input_ids_flat = input_ids.view(-1, 128)
        attention_masks_flat = attention_masks.view(-1, 128)
        outputs = self.bert(input_ids=input_ids_flat, attention_mask=attention_masks_flat)
        pooler_output = outputs.pooler_output
        pooler_output = pooler_output.view(batch_size, 5, -1)
        # user_review_attn.append(pooler_output)
        for i in range(batch_size):
            query = user_id_embedding[i]
            key = pooler_output[i]
            value = pooler_output[i]
            weighted_output, attention_map = self.multihead_attn(query, key, value)
            # Append the attention-weighted output to the list
            item_review_attn.append(weighted_output)

        # Perform contrastive learning within the batch for item reviews
        item_review_attn = torch.stack(item_review_attn, dim=0)  # shape: (batch_size, hidden_size)
        item_review_attn_pos_idx = torch.LongTensor([i for i in range(batch_size)]).to(device)
        item_pooled_output = item_review_attn[item_review_attn_pos_idx]
        item_review_attn_pos = item_id_embedding[item_review_attn_pos_idx].squeeze(1)
        item_review_attn_neg_idx = torch.LongTensor([random.choice([j for j in range(batch_size) if j != i]) for i in range(batch_size)]).to(device)
        item_review_attn_neg = item_id_embedding[item_review_attn_neg_idx].squeeze(1)
        item_review_attn_loss = self.triplet_loss(item_review_attn, item_review_attn_pos, item_review_attn_neg)

        match_loss =(user_review_attn_loss + item_review_attn_loss)
        user_review_attn = user_review_attn.squeeze(1)
        item_review_attn = item_review_attn.squeeze(1)
        pooled_output = torch.cat((user_review_attn, item_review_attn), dim=1)
        dropout_output = self.dropout(pooled_output)
        linear_output = self.attention_linear(dropout_output).squeeze(-1)
        # match_loss = 0
        return linear_output, match_loss

class LoRARegressor(nn.Module):
    def __init__(self, user_reviews, item_reviews, config, ckpt_list, dropout=0.5):
        super(LoRARegressor, self).__init__()
        # self.bert = BertModel.from_pretrained('bert-base-cased')
        self.lora = LoRAModel(config, ckpt_list, dropout=dropout)
        self.tokenizer = BertTokenizer.from_pretrained('bert-base-cased')
        self.user_reviews = user_reviews
        self.item_reviews = item_reviews
        self.dropout = nn.Dropout(dropout)
        self.linear = nn.Linear(768, 1)
        self.contrastive_loss = InfoNCELoss(temperature=0.2)
        self.attention_linear = nn.Linear(1536, 1)
        self.multihead_attn = torch.nn.MultiheadAttention(768, 8, 0)
        self.triplet_loss = TripletLoss(margin=1.0)

    def forward(self,user_id, item_id):
        user_id_embedding = emb_for_uid(user_id)
        item_id_embedding = emb_for_iid(item_id)
        user_review_attn = []
        item_review_attn = []
        user_reviews_input = []
        item_review_input = []
        for i in range(batch_size):
            review_input = []
            for j in range(5):  # Limit the number of reviews to 5
                if j < len(self.user_reviews[user_id[i].item()]):
                    review = self.user_reviews[user_id[i].item()][j]
                else:
                    review = ""  # Fill with empty string if the number of reviews is less than 5
                input_tokens = self.tokenizer(review,
                                              padding='max_length',
                                              truncation=True,
                                              max_length=128,
                                              add_special_tokens=True)
                input_id_tensor = torch.tensor(input_tokens['input_ids']).unsqueeze(0)
                attention_mask_tensor = torch.tensor(input_tokens['attention_mask']).unsqueeze(0)
                input_id_tensor = input_id_tensor.to(device)
                attention_mask_tensor = attention_mask_tensor.to(device)
                review_input.append((input_id_tensor, attention_mask_tensor))

            input_ids = torch.cat([t[0] for t in review_input], dim=0).unsqueeze(0)
            attention_masks = torch.cat([t[1] for t in review_input], dim=0).unsqueeze(0)
            user_reviews_input.append((input_ids, attention_masks))

        input_ids = torch.cat([t[0] for t in user_reviews_input], dim=0)
        attention_masks = torch.cat([t[1] for t in user_reviews_input], dim=0)
        input_ids_flat = input_ids.view(-1, 128)
        attention_masks_flat = attention_masks.view(-1, 128)
        outputs = self.lora(input_ids=input_ids_flat, attention_mask=attention_masks_flat)
        pooler_output = outputs
        pooler_output = pooler_output.view(batch_size, 5, -1)
        # user_review_attn.append(pooler_output)
        for i in range(batch_size):
            query = item_id_embedding[i]
            key = pooler_output[i]
            value = pooler_output[i]
            weighted_output, attention_map = self.multihead_attn(query, key, value)
            # Append the attention-weighted output to the list
            user_review_attn.append(weighted_output)

        # Contrastive learning within the batch for user reviews
        user_review_attn = torch.stack(user_review_attn, dim=0)  # shape: (batch_size, hidden_size)
        user_review_attn_pos_idx = torch.LongTensor([i for i in range(batch_size)]).to(device)
        user_pooled_output = user_review_attn[user_review_attn_pos_idx]
        user_review_attn_pos = user_id_embedding[user_review_attn_pos_idx].squeeze(1)
        user_review_attn_neg_idx = torch.LongTensor([random.choice([j for j in range(batch_size) if j != i]) for i in range(batch_size)]).to(device)
        user_review_attn_neg = user_id_embedding[user_review_attn_neg_idx].squeeze(1)
        user_review_attn_loss = self.triplet_loss(user_review_attn, user_review_attn_pos, user_review_attn_neg)

        # Processing each review for the item
        for i in range(batch_size):
            review_input = []
            for j in range(5):  # Limit the number of reviews to 5
                if j < len(self.item_reviews[item_id[i].item()]):
                    review = self.item_reviews[item_id[i].item()][j]
                else:
                    review = ""

                input_tokens = self.tokenizer(review,
                                              padding='max_length',
                                              truncation=True,
                                              max_length=128,
                                              add_special_tokens=True)
                input_id_tensor = torch.tensor(input_tokens['input_ids']).unsqueeze(0)
                attention_mask_tensor = torch.tensor(input_tokens['attention_mask']).unsqueeze(0)
                input_id_tensor = input_id_tensor.to(device)
                attention_mask_tensor = attention_mask_tensor.to(device)
                review_input.append((input_id_tensor, attention_mask_tensor))

            input_ids = torch.cat([t[0] for t in review_input], dim=0).unsqueeze(0)
            attention_masks = torch.cat([t[1] for t in review_input], dim=0).unsqueeze(0)
            item_review_input.append((input_ids, attention_masks))

        input_ids = torch.cat([t[0] for t in item_review_input], dim=0)
        attention_masks = torch.cat([t[1] for t in item_review_input], dim=0)
        input_ids_flat = input_ids.view(-1, 128)
        attention_masks_flat = attention_masks.view(-1, 128)
        outputs = self.lora(input_ids=input_ids_flat, attention_mask=attention_masks_flat)
        pooler_output = outputs
        pooler_output = pooler_output.view(batch_size, 5, -1)
        for i in range(batch_size):
            query = user_id_embedding[i]
            key = pooler_output[i]
            value = pooler_output[i]
            weighted_output, attention_map = self.multihead_attn(query, key, value)
            # Append the attention-weighted output to the list
            item_review_attn.append(weighted_output)

        # Contrastive learning within the batch for item reviews
        item_review_attn = torch.stack(item_review_attn, dim=0)  # shape: (batch_size, hidden_size)
        item_review_attn_pos_idx = torch.LongTensor([i for i in range(batch_size)]).to(device)
        item_pooled_output = item_review_attn[item_review_attn_pos_idx]
        item_review_attn_pos = item_id_embedding[item_review_attn_pos_idx].squeeze(1)
        item_review_attn_neg_idx = torch.LongTensor([random.choice([j for j in range(batch_size) if j != i]) for i in range(batch_size)]).to(device)
        item_review_attn_neg = item_id_embedding[item_review_attn_neg_idx].squeeze(1)
        item_review_attn_loss = self.triplet_loss(item_review_attn, item_review_attn_pos, item_review_attn_neg)

        match_loss =(user_review_attn_loss + item_review_attn_loss)
        user_review_attn = user_review_attn.squeeze(1)
        item_review_attn = item_review_attn.squeeze(1)
        pooled_output = torch.cat((user_review_attn, item_review_attn), dim=1)
        dropout_output = self.dropout(pooled_output)
        linear_output = self.attention_linear(dropout_output).squeeze(-1)

        return linear_output, match_loss



def compute_mse(predictions, labels):
    mse_loss = nn.MSELoss()  # Mean Squared Error loss
    mse = mse_loss(predictions, labels)  # Calculate MSE loss
    return mse.item()

R = 32
LORA_ALPHA = 32
LORA_DROPOUT=0.5
TARGET_MODULES = ["query","value","linear","dense"]

config = LoraConfig(
    r=R,  # Set R parameter
    lora_alpha=LORA_ALPHA,  # Set LoRA alpha parameter
    target_modules=TARGET_MODULES,  # Define target modules
    lora_dropout=LORA_DROPOUT,  # Set dropout for LoRA
    bias="none",  # Set bias type
    task_type="regression",  # Set task type as regression
)
# Create model instance
# Get the LoRA model
print("Start data Processing!")
dataset,user_reviews, item_reviews = process_data()  # Process data
train_data, eval_data, test_data = split_data(dataset, 0.8, 0.1, 0.1)  # Split data into train, evaluation, and test sets
# Fill in according to the actual size of the dataset
emb_for_uid = nn.Embedding(1000, 768).cuda()  # Create an embedding for user IDs
emb_for_iid = nn.Embedding(1000, 768).cuda()  # Create an embedding for item IDs
# ckpt_list = ["lorapreElec/my_model1.pth",'lorapre_Movies/my_model.pth']
ckpt_list = ["lorapreElec/my_model1.pth",'lorapre_Movies/my_model.pth','lorapre_CD/my_model.pth']
# Define the checkpoint list for model loading
model = LoRARegressor(user_reviews, item_reviews,config,ckpt_list)  # Initialize LoRA regressor model
use_cuda = torch.cuda.is_available()  # Check if CUDA is available
device = torch.device("cuda" if use_cuda else "cpu")  # Set the device to CUDA if available, otherwise CPU
# Define loss function and optimizer
if use_cuda:
    model = model.cuda()  # Move the model to GPU if available
new_R = 32
new_LORA_ALPHA = 32
new_TARGET_MODULES = ["query", "value", "linear", "dense"]
new_LORA_DROPOUT = 0.5

# Create a new LoraConfig instance with updated parameters
new_lora_config = LoraConfig(
    r=new_R,
    lora_alpha=new_LORA_ALPHA,
    target_modules=new_TARGET_MODULES,
    lora_dropout=new_LORA_DROPOUT,
    bias="none",
    task_type="regression",
)

# Get the PEFT model with the new LoraConfig
model = get_peft_model(model, new_lora_config)

# Set specific model parameters to require gradient calculation
for name, para in model.named_parameters():
    if ('lora' in name) or ('id' in name) or ('attention_linear' in name) or ('multi' in name):
        para.requires_grad = True

# Print the model's parameter names and their respective gradient requirement status
for name, para in model.named_parameters():
    print(name, para.requires_grad)

# Define the optimizer for model training
optimizer = Adam(model.parameters(), lr=1e-5)

num_epochs = 5
batch_size = 4
max_accuracy = 0
match_loss_weight = 0.2
model.train()

# Create data loaders for training, validation, and testing data
train_dataloader = DataLoader(train_data, batch_size=batch_size, shuffle=True, drop_last=True)
val_dataloader = DataLoader(eval_data, batch_size=batch_size, shuffle=True, drop_last=True)
test_dataloader = DataLoader(test_data, batch_size=batch_size, shuffle=True, drop_last=True)

# Train the model for multiple epochs
for epoch in range(num_epochs):
    total_loss_train = 0
    for idx, batch in enumerate(tqdm(train_dataloader)):
        labels = batch['label_tensor'].squeeze().to(device)
        user_ids = batch['user_id_tensor'].to(device)
        item_ids = batch['item_id_tensor'].to(device)
        outputs, match_loss = model(user_ids, item_ids)
        loss_fn = nn.MSELoss()
        loss = loss_fn(outputs, labels) + match_loss * match_loss_weight
        total_loss_train += loss.item()
        loss.backward()
        optimizer.step()
        optimizer.zero_grad()

    total_predictions_val = 0
    total_mse_val = 0.0
    model.eval()

    # Validate the model on the validation set
    with torch.no_grad():
        for batch_val in tqdm(val_dataloader):
            labels_val = batch_val['label_tensor'].squeeze().to(device)
            user_ids = batch_val['user_id_tensor'].to(device)
            item_ids = batch_val['item_id_tensor'].to(device)
            output_val, match_loss = model(user_ids, item_ids)
            total_predictions_val += len(output_val)
            mse_val = compute_mse(output_val, labels_val)
            total_mse_val += mse_val * len(output_val)

    mse_val = total_mse_val / total_predictions_val
    print("Epoch {}: Training Loss: {:.4f}, Val MSE: {:.4f}".format(epoch + 1,
                                                                    total_loss_train / len(train_data) * batch_size,
                                                                    mse_val))

    # Evaluate the performance of the model on the test set
    total_predictions_test = 0
    total_mse_test = 0.0
    model.eval()

    with torch.no_grad():
        for batch_test in tqdm(test_dataloader):
            labels_test = batch_test['label_tensor'].squeeze().to(device)
            user_ids = batch_test['user_id_tensor'].to(device)
            item_ids = batch_test['item_id_tensor'].to(device)
            output_test, match_loss = model(user_ids, item_ids)
            total_predictions_test += len(output_test)
            mse_test = compute_mse(output_test, labels_test)
            total_mse_test += mse_test * len(output_test)

    mse_test = total_mse_test / total_predictions_test
    print("MSE on Test Set: {:.4f}".format(mse_test))
