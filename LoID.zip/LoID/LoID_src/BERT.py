import torch
from transformers import BertTokenizer, BertModel
from torch import nn
from torch.utils.data import Dataset, DataLoader
import json
from tqdm import tqdm
import torch.nn.parallel
import numpy as np
from torch.optim import Adam
import argparse
from peft import LoraModel, get_peft_model, LoraConfig, PeftModel
import os
import pandas as pd
import torch.nn.functional as F
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.metrics import precision_recall_fscore_support

parser = argparse.ArgumentParser()
parser.add_argument("-rs", dest="random_seed", type=int, default=1337, help="Random Seed (Default: 1337)")

args = parser.parse_args()

# Initial Setup
np.random.seed(args.random_seed)
torch.manual_seed(args.random_seed)

# Function to split data into training, evaluation, and testing sets
def split_data(data, train_ratio, eval_ratio, test_ratio):
    np.random.shuffle(data)  # Randomly shuffle the data
    num_total = len(data)

    num_train = int(num_total * train_ratio)
    num_eval = int(num_total * eval_ratio)
    num_test = num_total - num_train - num_eval

    train_data = data[:num_train]
    eval_data = data[num_train:num_train + num_eval]
    test_data = data[num_train + num_eval:]

    return train_data, eval_data, test_data

# Function to process the data
def process_data():
    ordata = []
    with open('datasets/reviews_digital_music.json', 'r') as f:
        for line in f:
            json_data = json.loads(line)
            ordata.append(json_data)

    preform_data = []  # Initialize a list to store processed data
    tokenizer = BertTokenizer.from_pretrained('bert-base-cased')
    for example in tqdm(ordata):  # Iterate over JSON data
        review = example['reviewText']
        label = example['overall'] - 1

        input_tokens = tokenizer(review, padding='max_length', truncation=True, max_length=512, add_special_tokens=True)
        input_id_tensor = torch.tensor(input_tokens['input_ids'])
        attention_mask_tensor = torch.tensor(input_tokens['attention_mask'])
        label_tensor = torch.tensor(label)

        preform_data.append({'input_id_tensor': input_id_tensor,
                             'attention_mask_tensor': attention_mask_tensor,
                             'label_tensor': label_tensor})

    return preform_data

# Define a custom classifier model using BERT
class BertClassifier(nn.Module):
    def __init__(self, dropout=0.5, num_classes=1):
        super(BertClassifier, self).__init__()
        self.bert = BertModel.from_pretrained('bert-base-cased')
        self.dropout = nn.Dropout(dropout)
        self.linear = nn.Linear(768, num_classes)

    def forward(self, input_id, mask):
        _, pooled_output = self.bert(input_ids=input_id, attention_mask=mask, return_dict=False)
        dropout_output = self.dropout(pooled_output)
        linear_output = self.linear(dropout_output)
        return linear_output.squeeze(1)

# Function to compute evaluation metrics
def compute_metrics(predictions, labels):
    preds = np.argmax(predictions, axis=1)
    acc = accuracy_score(labels, preds)
    precision = precision_score(labels, preds, average='macro')
    recall = recall_score(labels, preds)
    f1 = f1_score(labels, preds)
    return {
        'accuracy': acc,
        'precision': precision,
        'recall': recall,
        'f1': f1
    }

model = BertClassifier(num_classes=1)  # Create an instance of the custom classifier model

use_cuda = torch.cuda.is_available()  # Check if CUDA is available
device = torch.device("cuda" if use_cuda else "cpu")  # Set the device to CUDA if available, else CPU

if use_cuda:
    model = model.cuda()  # Move the model to CUDA

optimizer = Adam(model.parameters(), lr=1e-5)

print("This is reviews_digital_music.json;PRF;bert")

dataset = process_data()  # Process the data
train_data, eval_data, test_data = split_data(dataset, 0.8, 0.1, 0.1)  # Split the dataset into training, evaluation, and testing sets
num_epochs = 5  # Set the number of epochs
batch_size = 2  # Set the batch size

model.train()  # Set the model to training mode
train_dataloader = DataLoader(train_data, batch_size=batch_size, shuffle=True)  # Create a dataloader for training data
val_dataloader = DataLoader(eval_data, batch_size=batch_size, shuffle=True)  # Create a dataloader for evaluation data
test_dataloader = DataLoader(test_data, batch_size, shuffle=True)  # Create a dataloader for testing data

for epoch in range(num_epochs):
    total_loss_train = 0
    for idx, batch in enumerate(tqdm(train_dataloader)):
        input_ids = batch['input_id_tensor'].to(device)
        attention_mask = batch['attention_mask_tensor'].to(device)
        labels = batch['label_tensor'].to(device)

        outputs = model(input_ids, attention_mask)
        loss_fn = nn.MSELoss()
        loss = loss_fn(outputs, labels)

        total_loss_train += loss.item()

        loss.backward()
        optimizer.step()
        optimizer.zero_grad()

    model.eval()

    val_predictions = []
    val_true_labels = []

    with torch.no_grad():
        for batch in tqdm(val_dataloader):
            input_ids = batch['input_id_tensor'].to(device)
            attention_mask = batch['attention_mask_tensor'].to(device)
            labels = batch['label_tensor'].to(device)

            outputs = model(input_ids, attention_mask)
            predicted_labels = torch.round(outputs).cpu().tolist()
            true_labels = labels.cpu().tolist()
            val_predictions.extend(predicted_labels)
            val_true_labels.extend(true_labels)

    precision, recall, f1, _ = precision_recall_fscore_support(val_true_labels, val_predictions, average='weighted')

    print(f"Validation Precision: {precision:.4f}")
    print(f"Validation Recall: {recall:.4f}")
    print(f"Validation F1-score: {f1:.4f}")

    test_predictions = []
    test_true_labels = []

    with torch.no_grad():
        for batch in tqdm(test_dataloader):
            input_ids = batch['input_id_tensor'].to(device)
            attention_mask = batch['attention_mask_tensor'].to(device)
            labels = batch['label_tensor'].to(device)

            outputs = model(input_ids, attention_mask)

            predicted_labels = torch.round(outputs).cpu().tolist()
            true_labels = labels.cpu().tolist()
            test_predictions.extend(predicted_labels)
            test_true_labels.extend(true_labels)

    precision, recall, f1, _ = precision_recall_fscore_support(test_true_labels, test_predictions, average='weighted')

    print(f"Test Precision: {precision:.4f}")
    print(f"Test Recall: {recall:.4f}")
    print(f"Test F1-score: {f1:.4f}")
