import torch
from transformers import BertTokenizer, BertModel
from torch import nn
from torch.utils.data import Dataset, DataLoader
import json
import random
from tqdm import tqdm
import torch.nn.parallel
import numpy as np
from torch.optim import Adam
import argparse
from peft import LoraModel,get_peft_model,LoraConfig
import pandas as pd
import os

parser = argparse.ArgumentParser()
parser.add_argument("-rs", dest="random_seed", type=int, default=1334, help="Random Seed (Default: 1337)")
parser.add_argument("-dc", dest="disable_cuda", type=int, default=0,
                    help="Disable CUDA? (Default: 0, i.e. run using GPU (if available))")
parser.add_argument("-gpu", dest="gpu", type=int, default=0, help="Which GPU to use? (Default: 0)")
parser.add_argument("-vb", dest="verbose", type=int, default=1,
                    help="Show debugging/miscellaneous information? (Default: 0, i.e. Disabled)")
parser.add_argument("-die", dest="disable_initial_eval", type=int, default=0,
                    help="Disable initial Dev/Test evaluation? (Default: 0, i.e. Disabled)")
parser.add_argument("-mve", dest="model_val_per_epoch", type=int, default=1,
                    help="Perform validation and save model every n epochs (Default: 1)")

args = parser.parse_args()

# Check for availability of CUDA and execute on GPU if possible
args.use_cuda = not args.disable_cuda and torch.cuda.is_available()
del args.disable_cuda
print(torch.cuda.is_available())

# Initial Setup
np.random.seed(args.random_seed)
torch.manual_seed(args.random_seed)

def split_data(data, train_ratio, eval_ratio):
    np.random.shuffle(data)  # 随机打乱数据
    num_total = len(data)

    num_train = int(num_total * train_ratio)
    num_eval = int(num_total * eval_ratio)

    train_data = data[:num_train]
    eval_data = data[num_train:num_train + num_eval]

    return train_data, eval_data

def process_data():
    # 读取JSON文件
    data = []
    with open('datasets/reviews_Movies_and_TV.json', 'r') as f:
        for line in f:
            json_data = json.loads(line)
            data.append(json_data)

    # 定义一个空列表用于存储处理后的数据
    preform_data = []
    tokenizer = BertTokenizer.from_pretrained('bert-base-cased')
    # 遍历JSON数据
    for example in tqdm(data):
        review = example['reviewText']
        label = example['overall']
        # 对输入进行编码
        input_tokens = tokenizer(review, padding='max_length', truncation=True, max_length=512, add_special_tokens=True)
        input_id_tensor = torch.tensor(input_tokens['input_ids'])
        attention_mask_tensor = torch.tensor(input_tokens['attention_mask'])
        label_tensor = torch.tensor(label)
        # 构建样本字典并添加到评估数据列表中
        preform_data.append({'input_id_tensor': input_id_tensor,
                             'attention_mask_tensor': attention_mask_tensor,
                             'label_tensor': label_tensor})

    return preform_data

def evaluate(model, eval_data):
    use_cuda = torch.cuda.is_available()
    device = torch.device("cuda" if use_cuda else "cpu")
    batch_size = 4
    val_dataloader = DataLoader(eval_data, batch_size=batch_size, shuffle=True)
    model.eval()
    # 在每个训练周期结束后，在验证集上评估模型
    total_predictions_val = 0
    total_mse_val = 0.0
    model.eval()
    with torch.no_grad():
        for batch_val in tqdm(val_dataloader):
            input_ids_val = batch_val['input_id_tensor'].to(device)
            attention_mask_val = batch_val['attention_mask_tensor'].to(device)
            labels_val = batch_val['label_tensor'].squeeze().to(device)

            output_val = model(input_ids_val, attention_mask_val)
            total_predictions_val += len(output_val)
            mse_val = compute_mse(output_val, labels_val)
            total_mse_val += mse_val * len(output_val)

    mse_val = total_mse_val / total_predictions_val
    return mse_val

def compute_mse(predictions, labels):
    mse_loss = nn.MSELoss()
    mse = mse_loss(predictions, labels)
    return mse.item()

class BertRegressor(nn.Module):
    def __init__(self, dropout=0.5):
        super(BertRegressor, self).__init__()
        self.bert = BertModel.from_pretrained('bert-base-cased')

        self.dropout = nn.Dropout(dropout)
        self.linear = nn.Linear(768, 1)
        self.relu = nn.ReLU()

    def forward(self, input_id, mask):
        _, pooled_output = self.bert(input_ids=input_id, attention_mask=mask, return_dict=False)
        dropout_output = self.dropout(pooled_output)
        linear_output = self.linear(dropout_output)
        return linear_output.squeeze(-1)

# 自定义数据集类
class MyDataset(torch.utils.data.Dataset):
    def __init__(self, file_path):
        self.data = pd.read_csv(file_path)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        input_id_tensor = torch.tensor(eval(self.data.iloc[index]['input_ids']))
        attention_mask_tensor = torch.tensor(eval(self.data.iloc[index]['attention_masks']))
        label_tensor = torch.tensor(self.data.iloc[index]['labels'])


        return {'input_id_tensor': input_id_tensor,
                'attention_mask_tensor': attention_mask_tensor,
                'label_tensor': label_tensor}


def train(model, train_data, eval_data):
    use_cuda = torch.cuda.is_available()
    device = torch.device("cuda" if use_cuda else "cpu")
    # device_ids = [0, 1]
    if use_cuda:
        model = model.cuda()
        # model = nn.DataParallel(model,device_ids=device_ids)

    checkpoint_path = "lorapre_Movies/my_model.pth"
    if os.path.exists(checkpoint_path):
        checkpoint = torch.load(checkpoint_path)
        model.load_state_dict(checkpoint['model_state_dict'])
        start_epoch = checkpoint['last_epoch']
        print(f"Resuming training from Epoch: {start_epoch}")
    else:
        start_epoch =0
        print(f"Starting training from:{start_epoch}")


    # step1. 参数配置
    R = 32
    LORA_ALPHA = 32
    LORA_DROPOUT = 0.2
    TARGET_MODULES = ["query", "value", "linear", "dense"]

    config = LoraConfig(
        r=R,
        lora_alpha=LORA_ALPHA,
        target_modules=TARGET_MODULES,
        lora_dropout=LORA_DROPOUT,
        bias="none",
        task_type="regression",
    )

    # step3. 获取LoRA模型
    model = get_peft_model(model, config)
    model.print_trainable_parameters()
    # # 加载预训练的BERT模型参数
    # checkpoint = torch.load('lora/my_model.pth')
    # model.load_state_dict(checkpoint['model_state_dict'],False)
    # print("loading saving model success")
    optimizer = Adam(model.parameters(), lr=1e-5)
    num_epochs = 6
    batch_size = 4
    min_mse = 100
    # 创建数据集对象
    train_dataloader = DataLoader(train_data, batch_size=batch_size, shuffle=True)
    model.train()
    for epoch in range(num_epochs):
        total_loss_train = 0
        for idx, batch in enumerate(tqdm(train_dataloader)):
            input_ids = batch['input_id_tensor'].to(device)
            attention_mask = batch['attention_mask_tensor'].to(device)
            labels = batch['label_tensor'].squeeze().to(device)
            outputs = model(input_ids, attention_mask)
            loss_fn = nn.MSELoss()
            loss = loss_fn(outputs, labels)
            total_loss_train += loss.item()
            loss.backward()
            optimizer.step()
            optimizer.zero_grad()

            if args.verbose and (idx + 1) % 100000 == 0:
                print(f"Epoch: {epoch + 1}, Batch: {idx + 1}, Loss: {loss.item()}")
                # 保存点设置
            if (idx + 1) % (len(train_dataloader) // 4) == 0:
                print(f"Saving checkpoint at Epoch: {epoch + 1}, Batch: {idx + 1}")
                state_dict = model.state_dict()
                torch.save({'last_epoch': epoch + 1, 'model_state_dict': state_dict},
                           f"lorapre_Movies/checkpoint_epoch{epoch + 1}_batch{idx + 1}.pth")
        if (epoch + 1) % args.model_val_per_epoch == 0:
            mse = evaluate(model, eval_data)
            print(f"Epoch: {epoch + 1}, Validation MSE: {mse}")
            if mse < min_mse:  # 判断MSE是否更小
                min_mse = mse
                state_dict = model.state_dict()
                torch.save({'last_epoch': epoch + 1, 'model_state_dict': state_dict}, "lorapre_Movies/my_model.pth")

        average_loss_train = total_loss_train / len(train_dataloader)
        print(f"Epoch: {epoch + 1}, Average Training Loss: {average_loss_train}")

# 创建模型实例
model = BertRegressor()
data = process_data()
train_data, eval_data = split_data(data, 0.8,0.2)
train(model, train_data,eval_data)
print("Successfully!")