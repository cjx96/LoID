#!/bin/bash
SCRIPT_PATH=$(cd $(dirname ${BASH_SOURCE[0]}); pwd)

MODELS_ROOT_DIR=/home/MMReco2021/xuwentao/pre
BASE_MODEL_PATH=${MODELS_ROOT_DIR}/a_origin_model
MIXTURE_ROOT_DIR=${MODELS_ROOT_DIR}

DARE_MODELS="e_music_save"

LORA_R=32
LORA_MODELS_ROOT_DIR=${MIXTURE_ROOT_DIR}/speechless-multi-loras-r${LORA_R}
mkdir -p ${LORA_MODELS_ROOT_DIR}

for DARE_MODEL in ${DARE_MODELS}; do
    DARE_MODEL_PATH=${MIXTURE_ROOT_DIR}/${DARE_MODEL}
    LORA_SAVE_PATH=${LORA_MODELS_ROOT_DIR}/${DARE_MODEL}-lora
    echo "Extracting LORA from ${DARE_MODEL_PATH} to ${LORA_SAVE_PATH}"
    PYTHONPATH=${SCRIPT_PATH}/.. \
    python -m multi_loras \
        extract_lora \
        --base_model_name_or_path ${BASE_MODEL_PATH} \
        --tuned_model_name_or_path ${DARE_MODEL_PATH} \
        --save_path ${LORA_SAVE_PATH} \
        --bf16 \
        --bits 4 \
        --lora_r ${LORA_R}
done
